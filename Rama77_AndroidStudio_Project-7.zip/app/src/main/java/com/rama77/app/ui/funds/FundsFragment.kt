package com.rama77.app.ui.funds

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.rama77.app.databinding.FragmentFundsBinding

class FundsFragment : Fragment() {

    private var _binding: FragmentFundsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFundsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvFundsBalance.text = "₹753"

        binding.btnAddCash.setOnClickListener {
            Toast.makeText(requireContext(), "Minimum deposit limit Rs. 300", Toast.LENGTH_SHORT).show()
        }

        binding.btnWithdrawCash.setOnClickListener {
            Toast.makeText(requireContext(), "Withdrawals processed 24/7", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}